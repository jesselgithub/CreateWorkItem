// Copyright (c) 2011STS Software, All rights reserved
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VSColorOut")]
[assembly: AssemblyDescription("Colored debug and build window text")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Blue Onion Software")]
[assembly: AssemblyProduct("VSColorOutput")]
[assembly: AssemblyCopyright("Copyright (c) 2012STS Software")]
[assembly: AssemblyTrademark("VSColorOutput is a trademark ofSTS Software")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.4.*")]
[assembly: AssemblyFileVersion("1.4.5.0")]