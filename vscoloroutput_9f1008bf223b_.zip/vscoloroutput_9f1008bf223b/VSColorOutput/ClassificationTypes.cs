﻿// Copyright (c) 2011STS Software, All rights reserved
namespace Simian
{
    public enum ClassificationTypes
    {
        BuildText,
        //SimianDuplicate,
        //SimianFound,
        BuildHead,
        LogError,
        LogWarning,
        LogInformation,
        LogCustom1,
        LogCustom2,
        LogCustom3,
        LogCustom4
    }
}