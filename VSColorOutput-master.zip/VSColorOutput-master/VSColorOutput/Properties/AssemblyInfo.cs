using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VSColorOutput")]
[assembly: AssemblyDescription("Color output for build and debug windows")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Mike Ward")]
[assembly: AssemblyProduct("VSColorOutput")]
[assembly: AssemblyCopyright("Copyright (c) 2016 Mike Ward")]
[assembly: AssemblyTrademark("VSColorOutput is a trademark of Mike Ward")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("2.5")]
[assembly: AssemblyFileVersion("2.5")]
[assembly: Guid("9D5A1B6F-D173-424E-B126-7A459F13DB7A")]

