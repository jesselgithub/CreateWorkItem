﻿namespace VSColorOutput.State
{
    public static class Runtime
    {
        public static bool RunningUnitTests { get; set; } = false;
    }
}